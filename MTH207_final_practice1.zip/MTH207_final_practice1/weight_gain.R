df = read.csv("weight_gain.csv")

summary(df)

boxplot(weight_gain~class_yr,data=df)

aov1 = aov(weight_gain ~ class_yr, data=df)
summary(aov1)
TukeyHSD(aov1)
